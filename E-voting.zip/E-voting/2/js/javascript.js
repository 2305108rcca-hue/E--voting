async function connect(){
    try{
        const provider = new ethers.BrowserProvider(window.ethereum);
            await provider.send("eth_requestAccounts", []);
        const signer = await provider.getSigner();
        const address = await signer.getAddress();
        const balance = await provider.getBalance(address);
        console.log(address);
        console.log(ethers.formatEther(balance) + " ETH");
        alert("Connected: " + address + "\nBalance: " + ethers.formatEther(balance) + " ETH");
}
catch(e){
        console.error("e :",e)
    }
}

document.getElementById("btnconnect").addEventListener("click",function(e){
 connect();
})