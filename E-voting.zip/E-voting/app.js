// // Wait until DOM is fully loaded
// document.addEventListener("DOMContentLoaded", () => {

//   const provider = new ethers.providers.Web3Provider(window.ethereum);
//   let signer;
//   let contract;

//   // --- IMPORTANT: Replace with your deployed contract address ---
//   const contractAddress = "0x93f8dddd876c7dBE3323723500e83E202A7C96CC"; // <<<--- REPLACE THIS WITH YOUR ACTUAL CONTRACT ADDRESS

//   // ABI (Application Binary Interface)
//   const abi = [
//     {
//       "inputs": [ { "internalType": "string", "name": "_name", "type": "string" } ],
//       "name": "addCandidate",
//       "outputs": [],
//       "stateMutability": "nonpayable",
//       "type": "function"
//     },
//     {
//       "inputs": [],
//       "stateMutability": "nonpayable",
//       "type": "constructor"
//     },
//     {
//       "inputs": [ { "internalType": "uint256", "name": "_candidateId", "type": "uint256" } ],
//       "name": "vote",
//       "outputs": [],
//       "stateMutability": "nonpayable",
//       "type": "function"
//     },
//     {
//       "anonymous": false,
//       "inputs": [
//         { "indexed": false, "internalType": "address", "name": "voter", "type": "address" },
//         { "indexed": false, "internalType": "uint256", "name": "candidateId", "type": "uint256" }
//       ],
//       "name": "Voted",
//       "type": "event"
//     },
//     {
//       "inputs": [ { "internalType": "uint256", "name": "", "type": "uint256" } ],
//       "name": "candidates",
//       "outputs": [
//         { "internalType": "uint256", "name": "id", "type": "uint256" },
//         { "internalType": "string", "name": "name", "type": "string" },
//         { "internalType": "uint256", "name": "voteCount", "type": "uint256" }
//       ],
//       "stateMutability": "view",
//       "type": "function"
//     },
//     { "inputs": [], "name": "candidatesCount", "outputs": [ { "internalType": "uint256", "name": "", "type": "uint256" } ], "stateMutability": "view", "type": "function" },
//     {
//       "inputs": [ { "internalType": "uint256", "name": "_candidateId", "type": "uint256" } ],
//       "name": "getCandidate",
//       "outputs": [
//         { "internalType": "string", "name": "name", "type": "string" },
//         { "internalType": "uint256", "name": "voteCount", "type": "uint256" }
//       ],
//       "stateMutability": "view",
//       "type": "function"
//     },
//     { "inputs": [], "name": "owner", "outputs": [ { "internalType": "address", "name": "", "type": "address" } ], "stateMutability": "view", "type": "function" },
//     { "inputs": [ { "internalType": "address", "name": "", "type": "address" } ], "name": "voters", "outputs": [ { "internalType": "bool", "name": "", "type": "bool" } ], "stateMutability": "view", "type": "function" }
//   ];

//   // --- DOM Elements ---
//   const connectBtn = document.getElementById("connectBtn");
//   const addCandidateBtn = document.getElementById("addCandidateBtn");
//   const candidateList = document.getElementById("candidateList");
//   const candidateNameInput = document.getElementById("candidateName");
//   const addCandidateDiv = document.getElementById("addCandidateDiv"); // Get the div for owner-only check

//   // --- Connect Wallet ---
//   async function connectWallet() {
//     if (!window.ethereum) {
//       alert("MetaMask not detected! Please install it. 🦊");
//       return;
//     }

//     try {
//       // Request account access
//       await provider.send("eth_requestAccounts", []);
//       signer = provider.getSigner();
//       const userAddress = await signer.getAddress();
//       console.log("Wallet connected:", userAddress);

//       // Initialize the contract instance
//       contract = new ethers.Contract(contractAddress, abi, signer);

//       // Check if the connected user is the owner and show/hide add candidate form
//       const ownerAddress = await contract.owner();
//       if (userAddress.toLowerCase() === ownerAddress.toLowerCase()) {
//         addCandidateDiv.style.display = "block"; // Show if owner
//       } else {
//         addCandidateDiv.style.display = "none"; // Hide if not owner
//       }

//       alert("Wallet connected successfully!");
//       loadCandidates(); // Load candidates after connection
//     } catch (err) {
//       console.error("Wallet connection error:", err);
//       alert("Failed to connect wallet: " + err.message);
//     }
//   }

//   // --- Add Candidate ---
//   async function addCandidate() {
//     const name = candidateNameInput.value.trim(); // Use trim to remove leading/trailing whitespace
//     if (!name) {
//       alert("Please enter a candidate name.");
//       return;
//     }

//     try {
//       // Call the addCandidate function on the smart contract
//       const tx = await contract.addCandidate(name);
//       await tx.wait(); // Wait for the transaction to be mined
//       alert(`Candidate "${name}" added successfully!`);
//       candidateNameInput.value = ""; // Clear the input field
//       loadCandidates(); // Reload the candidate list
//     } catch (err) {
//       console.error("Add candidate error:", err);
//       alert("Error adding candidate: " + err.message);
//     }
//   }

//   // --- Vote for candidate ---
//   async function vote(candidateId) {
//     if (!contract) {
//       alert("Please connect your wallet first.");
//       return;
//     }
//     try {
//       // Call the vote function on the smart contract
//       const tx = await contract.vote(candidateId);
//       await tx.wait(); // Wait for the transaction to be mined
//       alert("Voted successfully!");
//       loadCandidates(); // Reload the candidate list
//     } catch (err) {
//       console.error("Vote error:", err);
//       alert("Error voting: " + err.message);
//     }
//   }

//   // --- Load Candidates ---
//   async function loadCandidates() {
//     if (!contract) {
//       // Don't try to load if contract is not initialized
//       return;
//     }
//     candidateList.innerHTML = ""; // Clear existing list
//     try {
//       const count = await contract.candidatesCount();
//       console.log(`Found ${count} candidates.`);
//       for (let i = 1; i <= count; i++) { // Assuming candidate IDs start from 1
//         const candidate = await contract.getCandidate(i);
//         const li = document.createElement("li");
//         li.innerHTML = `
//           ${candidate.name} - Votes: ${candidate.voteCount}
//           <button class="voteBtn" data-id="${i}">Vote</button>
//         `;
//         candidateList.appendChild(li);
//       }

//       // Attach event listeners to the newly created vote buttons
//       document.querySelectorAll(".voteBtn").forEach(btn => {
//         btn.addEventListener("click", () => {
//           const candidateId = btn.getAttribute("data-id");
//           vote(candidateId);
//         });
//       });
//     } catch (err) {
//       console.error("Error loading candidates:", err);
//       alert("Could not load candidates: " + err.message);
//     }
//   }

//   // --- Event Listeners ---
//   connectBtn.addEventListener("click", connectWallet);
//   addCandidateBtn.addEventListener("click", addCandidate);

//   // --- Initial check for wallet connection on page load ---
//   // This is useful if the user already has MetaMask connected and has visited the page before.
//   async function checkWalletConnection() {
//     if (window.ethereum && window.ethereum.selectedAddress) {
//       await connectWallet();
//     }
//   }
//   checkWalletConnection();

// });



async function connect(){
    try{
        const provider=new ethers.BrowserProvider(window.ethereum);
        const signer=await provider.getSigner();
        const address=await signer.getAddress();
        const balance=await provider.getBalance(address);
        console.log(address);
        console.log(balance);
    }
    catch(e){
        console.error("e :",e)
    }
}
document.getElementById("connectBtn").addEventListener("click",function(){
    connect();
})